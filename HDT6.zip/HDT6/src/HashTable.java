
import java.util.Set;
import java.util.TreeSet;

/**
* Clase HashTable
* @author Ramón Samayoa, Diego Valdez
* @version 05.09.2016
*/
public class HashTable {
    //Se crea la clase Facory
    Factory factory = new Factory(); 
    
    // Se crean las variables a utilizar
    private Set<String> Conjunto;
    private Set<String> SubConjunto;
    private String ConjuntoMayor;
    
    
    //Constructor para inicizlizar los conjuntos y variables

    /**
     *
     * @param seleccion: int
     * Se instancia con el factory
     */
        public HashTable(int seleccion){
        Conjunto = factory.getStackType(seleccion);
        SubConjunto = factory.getStackType(seleccion);
        ConjuntoMayor = "";
    }
    

    /**
     *
     * @param elemento: String
     * Agrega un elemento al conjunto
     */
        public void setTable(String elemento){
        Conjunto.add(elemento);
        
    }
    

    /**
     *
     * @return Conjunto
     * Metodo para retornar el conjunto.
     */
        public Set<String> getConjunto(){
        return Conjunto;
    }
    

    /**
     *
     * @param conj1 : Set
     * @param conj2 : Set
     * @param conj3 : Set
     * @return SubConjunto
     * Mira Quienes estan en todas las categorias.
     */
        public Set<String> InterseccionTriple(Set<String> conj1 ,Set<String> conj2, Set<String> conj3){
        SubConjunto.clear();
        SubConjunto.addAll(conj1);
        SubConjunto.retainAll(conj2);
        SubConjunto.retainAll(conj3);
        
        return SubConjunto;
    }

    /**
     *
     * @param conj1 : Set
     * @param conj2 : Set
     * @return SubConjunto
     * Metodo donde se ingresan dos conjuntos y se retorna todos los elementos de A que no estan contenidos en B
     */
        public Set<String> Inclusion(Set<String> conj1, Set<String> conj2){
        SubConjunto.clear();
        SubConjunto.addAll(conj1);
        SubConjunto.removeAll(conj2);
        return SubConjunto;
    }
    
    
    

    /**
     *
     * @param conj1 : Set
     * @param conj2 : Set
     * @return
     * Metodo donde se ingresan dos conjuntos y se retorna la interseccion de ambos.
     */
        public Set<String> InterseccionDoble(Set<String> conj1, Set<String> conj2){
        SubConjunto.clear();
        SubConjunto.addAll(conj1);
        SubConjunto.retainAll(conj2);
        return SubConjunto;
    }
    

    /**
     *
     * @param conj1: Set
     * @param conj2: Set
     * @return Subconjunto
     * Metodo donde se ingresan dos conjuntos y se retorna un conjunto con la union de estos dos
     */
        public Set<String> Union(Set<String> conj1, Set<String> conj2){
        SubConjunto.clear();
        SubConjunto.addAll(conj1);
        SubConjunto.addAll(conj2);
        return SubConjunto;
    }
    

    /**
     *
     * @param conj1: Set
     * @param conj2: Set
     * @return: boolean
     * Metodo para determinar si un conjunto esta contenido en otro.
     */
        public boolean VefSubConjunto(Set<String> conj1, Set<String> conj2){
        SubConjunto.clear();
        SubConjunto.addAll(conj1);
        SubConjunto.retainAll(conj2);
        
        if (SubConjunto.size() == conj1.size()){
            return true;
        }
        else{
            return false;
        }
    }
    
    

    /**
     *
     * @param conj1: Set
     * @param conj2: Set
     * @param conj3: Set
     * @return Subconjunto
     * Metodo que compara tres conjuntos y devuelve el conjunto mas grande.
     */
        public Set<String> ConjuntoGrande(Set<String> conj1, Set<String> conj2, Set<String> conj3){
        SubConjunto.clear();
        if ((conj1.size() >= conj2.size()) && (conj1.size() >= conj3.size())){
            SubConjunto.addAll(conj1);
            ConjuntoMayor = "    Desarrolladores Java";
        }
        else if ((conj2.size() >= conj1.size()) && (conj2.size() >= conj3.size())){
            SubConjunto.addAll(conj2);
            ConjuntoMayor = "    Desarrolladores Web";
        }
        else if ((conj3.size() >= conj2.size()) && (conj3.size() >= conj1.size())){
           ConjuntoMayor = "    Desarrolladores Celulares";
           SubConjunto.addAll(conj3);
        }
        System.out.println(ConjuntoMayor);
        return SubConjunto;
    }
    

    /**
     *
     * @param conj1: Set
     * @return cadena
     * Metodo para imprimir un conjunto de manera ascendente.
     */
        public String PrintConjuntoAsc(Set<String> conj1){
        TreeSet<String> ts=new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
        ts.addAll(conj1);
        String cadena = ts.toString();
        cadena=cadena.replace("]", "         ");
        cadena=cadena.replace("[", " ");
        cadena=cadena.replace(",", "\n         ");
        return cadena;
        
    }
}
