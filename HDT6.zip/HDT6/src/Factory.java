import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;
import java.util.Set;

/**
* Clase Factory
* @author Ramón Samayoa, Diego Valdez
* @version 05.09.2016
*/
public class Factory {

    /**
     *
     * @param seleccion: int
     * @return null
     * Recibe la selección de la instancia
     */
    public Set<String> getStackType (int seleccion){
        
        if(seleccion == 1){
            return new HashSet<String>();
        }
        
        else if(seleccion == 2){
            return new TreeSet<String>();
        }
        
        else if(seleccion == 3){
            return new LinkedHashSet<String>();
        }
        
        return null;
    }
}
